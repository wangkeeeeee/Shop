package pers.wangke.shop.filter;

import pers.wangke.shop.dao.USER_Dao;
import pers.wangke.shop.pojo.USER;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebFilter("/register")
public class Register implements Filter{
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        //对req和resp进行类型转换
        HttpServletRequest req = (HttpServletRequest)servletRequest;
        HttpServletResponse resp = (HttpServletResponse)servletResponse;

        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        String k = "";

        PrintWriter out = resp.getWriter();


        //如果id为空值或者id已经被注册，如果为开始拦截，返回注册界面
        String id = req.getParameter("id");

        if (k.equals(id)){
            out.write("<script>");
            out.write("alert('用户名ID不能为空');");
            out.write("location.href='reg.jsp';");
            out.write("</script>");
            out.close();
            return;
        }else if (USER_Dao.selectById(id) != null){
            out.write("<script>");
            out.write("alert('用户名ID不能重复');");
            out.write("location.href='reg.jsp';");
            out.write("</script>");
            out.close();
            return;
        }
        //判断用户姓名
        String name = req.getParameter("name");
        if (k.equals(name)){
            out.write("<script>");
            out.write("alert('用户姓名不能为空');");
            out.write("location.href='reg.jsp';");
            out.write("</script>");
            out.close();
            return;
        }
        //判断验证码
        String captcha = req.getParameter("captcha");
        HttpSession session = req.getSession();
        String code = (String) session.getAttribute("code");
        if (!code.equals(captcha)){
            out.write("<script>");
            out.write("alert('验证码不正确');");
            out.write("location.href='reg.jsp';");
            out.write("</script>");
            out.close();
            return;
        }


        filterChain.doFilter(req,resp);
    }

    @Override
    public void destroy() {

    }
}
