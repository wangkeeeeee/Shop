package pers.wangke.shop.dao;

import pers.wangke.shop.pojo.CATEGORY;
import pers.wangke.shop.pojo.USER;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CATE_Dao {

    //查询所有分类
    public static ArrayList<CATEGORY> selectAll(){
        ArrayList<CATEGORY> list = new ArrayList<>();

        ResultSet rs = null;
        Connection conn = BaseDao.getconn();

        PreparedStatement ps = null;


        try {
            String sql = "select * from category";
            ps = conn.prepareStatement(sql);

            rs = ps.executeQuery();

            while (rs.next()){
                CATEGORY cate =  new CATEGORY(
                        rs.getInt("CATE_ID"),
                        rs.getString("CATE_NAME"),
                        rs.getInt("CATE_PARENT_ID")
                );

                list.add(cate);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }


        return list;
    }

    //新增分类
    public static int insert(CATEGORY cate){
        String sql = "insert into category values(null,?, ?)";

        Object[] params = {
                cate.getCATE_NAME(),
                cate.getCATE_PARENT_ID()
        };

        return BaseDao.exectuIUD(sql,params);
    }

    //根据ID查找分类
    public static CATEGORY selectById(int id){
        CATEGORY cate = null;
        //声明结果集
        ResultSet rs = null;
        //获取连接对象
        Connection conn = BaseDao.getconn();

        PreparedStatement ps = null;

        try {
            String sql = "select * from category where CATE_ID = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1,id);

            rs = ps.executeQuery();

            while (rs.next()) {
                cate = new CATEGORY(
                        rs.getInt("CATE_ID"),
                        rs.getString("CATE_NAME"),
                        rs.getInt("CATE_PARENT_ID")
                );
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }
        return cate;
    }

    //更新分类
    public static int update(CATEGORY cate){
        int count = 0;
        String sql = "update category set CATE_NAME=?,CATE_PARENT_ID=? where CATE_ID=?";

        Object[] params = {
                cate.getCATE_NAME(),
                cate.getCATE_PARENT_ID(),
                cate.getCATE_ID()
        };
        count = BaseDao.exectuIUD(sql, params);

        return count;
    }

    //删除分类
    public static int del(int id){
        String sql = "delete from category where CATE_ID=?";

        Object[] params = {
                id
        };

        return BaseDao.exectuIUD(sql,params);
    }

    //查询分类，子分类和父级分类  flag="father" flag="child"
    public static ArrayList<CATEGORY> selectCate(String flag){
        ArrayList<CATEGORY> list = new ArrayList<>();
        //声明结果集
        ResultSet rs = null;
        //获取连接对象
        Connection conn = BaseDao.getconn();

        PreparedStatement ps = null;



        try {
            String sql = null;

            if (flag != null && flag.equals("father")){

                sql = "select * from category where CATE_PARENT_ID=0";
            }else {
                sql = "select * from category where CATE_PARENT_ID != 0";
            }

            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()){
                CATEGORY cate = new CATEGORY(
                        rs.getInt("CATE_ID"),
                        rs.getString("CATE_NAME"),
                        rs.getInt("CATE_PARENT_ID")
                );

                list.add(cate);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }

        return list;
    }
}
