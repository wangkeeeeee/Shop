package pers.wangke.shop.dao;

import pers.wangke.shop.pojo.CART;
import pers.wangke.shop.pojo.CATEGORY;
import pers.wangke.shop.pojo.PRODUCT;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CART_Dao {

    //创建购物车
    public static int insert(CART cart){
        String sql = "insert into cart values(null, ?, ?, ?, ?, ?, ?, ?, ?)";

        Object[] params = {
                cart.getCART_P_FILENAME(),
                cart.getCART_P_NAME(),
                cart.getCART_P_PRICE(),
                cart.getCART_QUANTITY(),
                cart.getCART_P_STOCK(),
                cart.getCART_P_ID(),
                cart.getCART_U_ID(),
                cart.getCART_VALID()
        };

        return BaseDao.exectuIUD(sql,params);
    }

    //根据用户ID查询购物车列表
    public static ArrayList<CART> selectCartById(String uid){
        ArrayList<CART> list = new ArrayList<>();
        //声明结果集
        ResultSet rs = null;
        //获取连接对象
        Connection conn = BaseDao.getconn();

        PreparedStatement ps = null;

        try {
            String sql = null;

            sql = "select * from cart where CART_U_ID=?";


            ps = conn.prepareStatement(sql);
            ps.setString(1,uid);
            rs = ps.executeQuery();

            while (rs.next()){
                CART cart = new CART(
                        rs.getInt("CART_ID"),
                        rs.getString("CART_P_FILENAME"),
                        rs.getString("CART_P_NAME"),
                        rs.getInt("CART_P_PRICE"),
                        rs.getInt("CART_QUANTITY"),
                        rs.getInt("CART_P_STOCK"),
                        rs.getInt("CART_P_ID"),
                        rs.getString("CART_U_ID"),
                        rs.getInt("CART_VALID")
                );
                list.add(cart);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }

        return list;
    }

    //根据UID和PID去查找购物车
    public static CART selectCartByUidAndPid(String uid,String pid){
        CART cart = null;
        //声明结果集
        ResultSet rs = null;
        //获取连接对象
        Connection conn = BaseDao.getconn();

        PreparedStatement ps = null;

        try {
            String sql = "select * from cart where CART_U_ID = ? and CART_P_ID = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1,uid);
            ps.setInt(2,Integer.parseInt(pid));

            rs = ps.executeQuery();

            while (rs.next()) {
                cart = new CART(
                        rs.getInt("CART_ID"),
                        rs.getString("CART_P_FILENAME"),
                        rs.getString("CART_P_NAME"),
                        rs.getInt("CART_P_PRICE"),
                        rs.getInt("CART_QUANTITY"),
                        rs.getInt("CART_P_STOCK"),
                        rs.getInt("CART_P_ID"),
                        rs.getString("CART_U_ID"),
                        rs.getInt("CART_VALID")
                );
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }
        return cart;
    }

    //根据ID去增加商品再购物车的数量
    public static int updateCountById(int count,int id){
        String sql = "update cart set CART_QUANTITY=? where CART_ID=?";

        Object[] params = {
                count,
                id
        };

        return BaseDao.exectuIUD(sql,params);
    }

    //根据ID删除记录
    public static int delete(int id){
        String sql = "delete from cart where CART_ID=?";

        Object[] params = {id};

        return BaseDao.exectuIUD(sql,params);
    }

    //根据ID去查找购物车
    public static CART selectCartByID(String id){
        CART cart = null;
        //声明结果集
        ResultSet rs = null;
        //获取连接对象
        Connection conn = BaseDao.getconn();

        PreparedStatement ps = null;

        try {
            String sql = "select * from cart where CART_ID = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1,id);

            rs = ps.executeQuery();

            while (rs.next()) {
                cart = new CART(
                        rs.getInt("CART_ID"),
                        rs.getString("CART_P_FILENAME"),
                        rs.getString("CART_P_NAME"),
                        rs.getInt("CART_P_PRICE"),
                        rs.getInt("CART_QUANTITY"),
                        rs.getInt("CART_P_STOCK"),
                        rs.getInt("CART_P_ID"),
                        rs.getString("CART_U_ID"),
                        rs.getInt("CART_VALID")
                );
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }
        return cart;
    }

}
