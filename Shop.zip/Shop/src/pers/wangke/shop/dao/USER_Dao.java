package pers.wangke.shop.dao;

import pers.wangke.shop.pojo.USER;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class USER_Dao {

    //创建用户
    public static int insert(USER user){
        String sql = "insert into user values(?, ?, ?, ?, DATE_FORMAT(?, '%Y-%m-%d'), ?, ?, ?, ?, ?)";

        Object[] params = {
                user.getUSER_ID(),
                user.getUSER_NAME(),
                user.getUSER_PASSWORD(),
                user.getUSER_SEX(),
                user.getUSER_BIRTHDAY(),
                user.getUSER_IDENITY_CODE(),
                user.getUSER_EMAIL(),
                user.getUSER_MOBILE(),
                user.getUSER_ADDRESS(),
                user.getUSER_STATUS()
        };

        return BaseDao.exectuIUD(sql,params);
    }

    //修改用户
    public static int updateUser(USER user){
        String sql = "update user set USER_NAME=?, USER_PASSWORD=?, USER_SEX=?, USER_BIRTHDAY=DATE_FORMAT(?, '%Y-%m-%d'), USER_IDENITY_CODE=?, USER_EMAIL=?, USER_MOBILE=?, USER_ADDRESS=?, USER_STATUS=? where USER_ID=?";

        Object[] params = {
                user.getUSER_NAME(),
                user.getUSER_PASSWORD(),
                user.getUSER_SEX(),
                user.getUSER_BIRTHDAY(),
                user.getUSER_IDENITY_CODE(),
                user.getUSER_EMAIL(),
                user.getUSER_MOBILE(),
                user.getUSER_ADDRESS(),
                user.getUSER_STATUS(),
                user.getUSER_ID()
        };

        return BaseDao.exectuIUD(sql,params);
    }


    //查询所有用户
    public static ArrayList<USER> selectAll(int cpage,int count,String keywords){
        ArrayList<USER> list = new ArrayList<>();
        //声明结果集
        ResultSet rs = null;
        //获取连接对象
        Connection conn = BaseDao.getconn();

        PreparedStatement ps = null;
        //查询语句，根据生日排序


        try {
            String sql = "";

            //判断用户是否传了关键字
            if (keywords != null){
                //用户传了关键字
                sql = "select * from user where USER_ID like ? order by USER_BIRTHDAY desc limit ?,?";
                ps = conn.prepareStatement(sql);
                ps.setString(1,"%"+keywords+"%");
                ps.setInt(2,(cpage-1)*count);
                ps.setInt(3,count);
            }else {
                //用户没传关键字
                sql = "select * from user order by USER_BIRTHDAY desc limit ?,?";
                ps = conn.prepareStatement(sql);

                ps.setInt(1,(cpage-1)*count);
                ps.setInt(2,count);
            }


            rs = ps.executeQuery();

            while (rs.next()){
               USER u = new USER(
                       rs.getString("USER_ID"),
                       rs.getString("USER_NAME"),
                       rs.getString("USER_PASSWORD"),
                       rs.getString("USER_SEX"),
                       rs.getString("USER_BIRTHDAY"),
                       rs.getString("USER_IDENITY_CODE"),
                       rs.getString("USER_EMAIL"),
                       rs.getString("USER_MOBILE"),
                       rs.getString("USER_ADDRESS"),
                       rs.getInt("USER_STATUS")
               );

               list.add(u);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }
        return list;
    }


    //获取总记录数和总页数
    public static int[] totalPage(int count,String keywords){
        //0 总记录数  1  页数
        int[] arr = {0,1};

        Connection conn = BaseDao.getconn();
        PreparedStatement ps = null;
        ResultSet rs = null;


        try {
            String sql = "";
            //判断是否有关键字传进来
            if (keywords != null){
                sql = "select count(*) from user where USER_ID like ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1,"%"+keywords+"%");

            }else {
                sql = "select count(*) from user";
                ps = conn.prepareStatement(sql);
            }



            rs = ps.executeQuery();
            while (rs.next()){
                arr[0] = rs.getInt(1);

                //用来判断分多少页
                if (arr[0]%count == 0){
                    arr[1] = arr[0]/count;
                }else {
                    arr[1] = arr[0]/count+1;
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }

        return arr;
    }

    //根据ID查找用户
    public static USER selectById(String id){
        USER user = null;
        //声明结果集
        ResultSet rs = null;
        //获取连接对象
        Connection conn = BaseDao.getconn();

        PreparedStatement ps = null;

        try {
            String sql = "select * from user where USER_ID = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1,id);

            rs = ps.executeQuery();

            while (rs.next()) {
                user = new USER(
                        rs.getString("USER_ID"),
                        rs.getString("USER_NAME"),
                        rs.getString("USER_PASSWORD"),
                        rs.getString("USER_SEX"),
                        rs.getString("USER_BIRTHDAY"),
                        rs.getString("USER_IDENITY_CODE"),
                        rs.getString("USER_EMAIL"),
                        rs.getString("USER_MOBILE"),
                        rs.getString("USER_ADDRESS"),
                        rs.getInt("USER_STATUS")
                );
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }
        return user;
    }

    //删除一个用户
    public static int del(String id){
        String sql = "delete from user where USER_ID=? and USER_STATUS!=2";

        Object[] params = {id};

        return BaseDao.exectuIUD(sql,params);
    }

}
