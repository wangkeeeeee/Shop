package pers.wangke.shop.dao;

import pers.wangke.shop.pojo.PRODUCT;
import pers.wangke.shop.pojo.USER;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PRODUCT_Dao {

    //新增一个产品
    public static int insert(PRODUCT product){
        String sql = "insert into product values(null,?,?,?,?,?,?,?)";

        Object[] params = {
                product.getPRODUCT_NAME(),
                product.getPRODUCT_DESCRIPTION(),
                product.getPRODUCT_PRICE(),
                product.getPRODUCT_STOCE(),
                product.getPRODUCT_FID(),
                product.getPRODUCT_CID(),
                product.getPRODUCT_FILENAME()
        };
        return BaseDao.exectuIUD(sql,params);
    }

    //查询所有产品
    public static ArrayList<PRODUCT> selectAll(){
        ArrayList<PRODUCT> products = new ArrayList<>();
        ResultSet rs = null;
        Connection conn = BaseDao.getconn();

        PreparedStatement ps =null;



        try {
            String sql = "select * from product";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()){
                PRODUCT product = new PRODUCT(
                        rs.getInt("PRODUCT_ID"),
                        rs.getString("PRODUCT_NAME"),
                        rs.getString("PRODUCT_DESCRIPTION"),
                        rs.getInt("PRODUCT_PRICE"),
                        rs.getInt("PRODUCT_STOCK"),
                        rs.getInt("PRODUCT_FID"),
                        rs.getInt("PRODUCT_CID"),
                        rs.getString("PRODUCT_FILENAME")
                );

                products.add(product);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }

        return products;
    }

    //查询fid查询所有产品
    public static ArrayList<PRODUCT> selectByfId(int id){
        ArrayList<PRODUCT> products = new ArrayList<>();
        ResultSet rs = null;
        Connection conn = BaseDao.getconn();

        PreparedStatement ps =null;



        try {
            String sql = "select * from product where PRODUCT_FID=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1,id);
            rs = ps.executeQuery();

            while (rs.next()){
                PRODUCT product = new PRODUCT(
                        rs.getInt("PRODUCT_ID"),
                        rs.getString("PRODUCT_NAME"),
                        rs.getString("PRODUCT_DESCRIPTION"),
                        rs.getInt("PRODUCT_PRICE"),
                        rs.getInt("PRODUCT_STOCK"),
                        rs.getInt("PRODUCT_FID"),
                        rs.getInt("PRODUCT_CID"),
                        rs.getString("PRODUCT_FILENAME")
                );

                products.add(product);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }

        return products;
    }

    //查询cid查询所有产品
    public static ArrayList<PRODUCT> selectBycId(int id){
        ArrayList<PRODUCT> products = new ArrayList<>();
        ResultSet rs = null;
        Connection conn = BaseDao.getconn();

        PreparedStatement ps =null;



        try {
            String sql = "select * from product where PRODUCT_CID=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1,id);
            rs = ps.executeQuery();

            while (rs.next()){
                PRODUCT product = new PRODUCT(
                        rs.getInt("PRODUCT_ID"),
                        rs.getString("PRODUCT_NAME"),
                        rs.getString("PRODUCT_DESCRIPTION"),
                        rs.getInt("PRODUCT_PRICE"),
                        rs.getInt("PRODUCT_STOCK"),
                        rs.getInt("PRODUCT_FID"),
                        rs.getInt("PRODUCT_CID"),
                        rs.getString("PRODUCT_FILENAME")
                );

                products.add(product);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }

        return products;
    }

    //根据产品ID查找产品
    public static PRODUCT selectById(String id){
        PRODUCT product = null;
        //声明结果集
        ResultSet rs = null;
        //获取连接对象
        Connection conn = BaseDao.getconn();

        PreparedStatement ps = null;

        try {
            String sql = "select * from product where PRODUCT_ID = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1,id);

            rs = ps.executeQuery();

            while (rs.next()) {
                product = new PRODUCT(
                        rs.getInt("PRODUCT_ID"),
                        rs.getString("PRODUCT_NAME"),
                        rs.getString("PRODUCT_DESCRIPTION"),
                        rs.getInt("PRODUCT_PRICE"),
                        rs.getInt("PRODUCT_STOCK"),
                        rs.getInt("PRODUCT_FID"),
                        rs.getInt("PRODUCT_CID"),
                        rs.getString("PRODUCT_FILENAME")
                );
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }
        return product;
    }

    //根据产品ID修改产品的库存
    public static int updateStock(int id,int stock){
        String sql = "update product set PRODUCT_STOCK=? where PRODUCT_ID=?";

        Object[] params = {
                stock,
                id
        };

        return BaseDao.exectuIUD(sql,params);
    }

    //根据关键字模糊查询商品
    public static ArrayList<PRODUCT> selectKeyword(String keyword){
        ArrayList<PRODUCT> products = new ArrayList<>();
        ResultSet rs = null;
        Connection conn = BaseDao.getconn();

        PreparedStatement ps =null;



        try {
            String sql = "select * from product where PRODUCT_NAME like ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1,"%"+keyword+"%");
            rs = ps.executeQuery();

            while (rs.next()){
                PRODUCT product = new PRODUCT(
                        rs.getInt("PRODUCT_ID"),
                        rs.getString("PRODUCT_NAME"),
                        rs.getString("PRODUCT_DESCRIPTION"),
                        rs.getInt("PRODUCT_PRICE"),
                        rs.getInt("PRODUCT_STOCK"),
                        rs.getInt("PRODUCT_FID"),
                        rs.getInt("PRODUCT_CID"),
                        rs.getString("PRODUCT_FILENAME")
                );

                products.add(product);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.closeall(rs,ps,conn);
        }

        return products;
    }

    //修改产品
    public static int update(PRODUCT product){
        String sql = "update product set PRODUCT_NAME = ?,PRODUCT_DESCRIPTION = ?,PRODUCT_PRICE = ?, PRODUCT_STOCK=?,PRODUCT_FID = ?,PRODUCT_CID = ? where PRODUCT_ID=?";

        Object[] params = {
                product.getPRODUCT_NAME(),
                product.getPRODUCT_DESCRIPTION(),
                product.getPRODUCT_PRICE(),
                product.getPRODUCT_STOCE(),
                product.getPRODUCT_FID(),
                product.getPRODUCT_CID(),
                product.getPRODUCT_ID()
        };

        return BaseDao.exectuIUD(sql,params);
    }

    //根据产品ID删除产品
    public static int delById(String id){
        String sql = "delete from product where PRODUCT_ID=?";

        Object[] params = {id};

        return BaseDao.exectuIUD(sql,params);
    }
}
