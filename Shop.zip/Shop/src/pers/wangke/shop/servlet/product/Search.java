package pers.wangke.shop.servlet.product;

import pers.wangke.shop.dao.CATE_Dao;
import pers.wangke.shop.dao.PRODUCT_Dao;
import pers.wangke.shop.pojo.CATEGORY;
import pers.wangke.shop.pojo.PRODUCT;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;


@WebServlet("/search")
public class Search extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取分类列表
        ArrayList<CATEGORY> flist = CATE_Dao.selectCate("father");
        ArrayList<CATEGORY> clist = CATE_Dao.selectCate("child");

        req.setAttribute("flist",flist);
        req.setAttribute("clist",clist);

        String keyword = req.getParameter("keyword");

        //根据关键字查找商品
        ArrayList<PRODUCT> prolist = PRODUCT_Dao.selectKeyword(keyword);

        req.setAttribute("prolist",prolist);

        req.getRequestDispatcher("productlist.jsp").forward(req,resp);


    }
}
