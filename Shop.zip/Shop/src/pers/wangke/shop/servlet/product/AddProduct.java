package pers.wangke.shop.servlet.product;

import com.jspsmart.upload.*;
import pers.wangke.shop.dao.PRODUCT_Dao;
import pers.wangke.shop.pojo.PRODUCT;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/manage/admin_addproduct")
public class AddProduct extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //创建SmartUpload对象，用来获取上传过来的文件
        SmartUpload smartUpload = new SmartUpload();
        //初始化
        smartUpload.initialize(this.getServletConfig(),req,resp);
        //上传过程
        try {
            smartUpload.upload();
        } catch (SmartUploadException e) {
            e.printStackTrace();
        }

        //获取上传的文件对象
        Files files = smartUpload.getFiles();
        //获取文件
        File file = files.getFile(0);
        //获取上传的文件名称
        String fileName = file.getFileName();

        //保存文件到目录
        try {
            smartUpload.save("D:\\WorkSpace\\Shop\\web\\images\\product");
        } catch (SmartUploadException e) {
            e.printStackTrace();
        }

        //获取前端参数
        Request request = smartUpload.getRequest();
        String cId = request.getParameter("cId");
        String productName = request.getParameter("productName");
        String productPrice = request.getParameter("productPrice");
        String productDesc = request.getParameter("productDesc");
        String productStock = request.getParameter("productStock");
        productName = new String(productName.getBytes(),"utf-8");
        productDesc = new String(productDesc.getBytes(),"utf-8");


        String flag = "";

        if (flag.equals(productName) ||  flag.equals(productPrice) ||  flag.equals(productDesc) || flag.equals(productDesc)){
            PrintWriter writer = resp.getWriter();
            writer.write("<script>");
            writer.write("alert('不能添加空值');");
            writer.write("location.href='admin_productadd';");
            writer.write("</script>");
            writer.close();
        }


        PRODUCT product = new PRODUCT(
                0,
                productName,
                productDesc,
                Integer.parseInt(productPrice),
                Integer.parseInt(productStock),
                Integer.parseInt(cId.split("_")[0]),
                Integer.parseInt(cId.split("_")[1]),
                fileName
        );

        //把产品对象存入数据库中
        int count = PRODUCT_Dao.insert(product);

        //判断是否添加成功
        if (count > 0){
            //添加成功
            resp.sendRedirect("admin_productselect");
        }else {
            //添加失败
            PrintWriter writer = resp.getWriter();
            writer.write("<script>");
            writer.write("alert('添加失败');");
            writer.write("location.href='admin_productadd';");
            writer.write("</script>");
            writer.close();
        }
    }
}
