package pers.wangke.shop.servlet.product;

import pers.wangke.shop.dao.CATE_Dao;
import pers.wangke.shop.dao.PRODUCT_Dao;
import pers.wangke.shop.pojo.CATEGORY;
import pers.wangke.shop.pojo.PRODUCT;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/manage/admin_toproductupdate")
public class ToProductUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //获取分类
        ArrayList<CATEGORY> flist = CATE_Dao.selectCate("father");
        ArrayList<CATEGORY> clist = CATE_Dao.selectCate("child");
        req.setAttribute("flist",flist);
        req.setAttribute("clist",clist);


        String pid = req.getParameter("pid");
        PRODUCT product = PRODUCT_Dao.selectById(pid);
        req.setAttribute("product",product);

        req.getRequestDispatcher("admin_productmodify.jsp").forward(req,resp);

    }
}
