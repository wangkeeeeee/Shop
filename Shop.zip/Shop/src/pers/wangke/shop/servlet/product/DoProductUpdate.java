package pers.wangke.shop.servlet.product;

import com.jspsmart.upload.*;
import pers.wangke.shop.dao.PRODUCT_Dao;
import pers.wangke.shop.pojo.PRODUCT;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/manage/admin_doproductupdate")
public class DoProductUpdate extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //创建SmartUpload对象，用来获取上传过来的文件
        SmartUpload smartUpload = new SmartUpload();
        //初始化
        smartUpload.initialize(this.getServletConfig(),req,resp);
        //上传过程
        try {
            smartUpload.upload();
        } catch (SmartUploadException e) {
            e.printStackTrace();
        }

        //获取上传的文件对象
        Files files = smartUpload.getFiles();
        //获取文件
        File file = files.getFile(0);
        //获取上传的文件名称
        String fileName = file.getFileName();



        //获取前端参数
        Request request = smartUpload.getRequest();
        String cId = request.getParameter("cId");
        String productName = request.getParameter("productName");
        String productPrice = request.getParameter("productPrice");
        String productDesc = request.getParameter("productDesc");
        String productStock = request.getParameter("productStock");
        productName = new String(productName.getBytes(),"utf-8");
        productDesc = new String(productDesc.getBytes(),"utf-8");



        String flag = "";

        if (flag.equals(productName) ||  flag.equals(productPrice) ||  flag.equals(productDesc) || flag.equals(productDesc)){
            PrintWriter writer = resp.getWriter();
            writer.write("<script>");
            writer.write("alert('不能添加空值');");
            writer.write("location.href='admin_productadd';");
            writer.write("</script>");
            writer.close();
        }


        PRODUCT product = new PRODUCT(
                Integer.parseInt(request.getParameter("pid")),
                productName,
                productDesc,
                Integer.parseInt(productPrice),
                Integer.parseInt(productStock),
                Integer.parseInt(cId.split("_")[0]),
                Integer.parseInt(cId.split("_")[1]),
                fileName
        );


        //修改产品
        int count = PRODUCT_Dao.update(product);



        //判断是否修改成功
        if (count > 0){
            //修改成功
            resp.sendRedirect("admin_productselect");
        }else {
            //修改失败
            PrintWriter writer = resp.getWriter();
            writer.write("<script>");
            writer.write("alert('修改失败');");
            writer.write("location.href='admin_productselect';");
            writer.write("</script>");
            writer.close();
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
