package pers.wangke.shop.servlet.cart;

import pers.wangke.shop.dao.CART_Dao;
import pers.wangke.shop.dao.PRODUCT_Dao;
import pers.wangke.shop.pojo.CART;
import pers.wangke.shop.pojo.PRODUCT;
import pers.wangke.shop.pojo.USER;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet("/cartadd")
public class CartAdd extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取前端参数
        String pid = req.getParameter("id");
        String count = req.getParameter("count");
        String url = req.getParameter("url");

        PRODUCT product = null;
        USER user = null;
        HttpSession session = req.getSession();
        String isLogin = String.valueOf(session.getAttribute("isLogin"));
        user = (USER) session.getAttribute("user");

        //判断用户是否登录
        if (user != null && "1".equals(isLogin)){
            //用户已经登录
            //根据UID 和 PID 查找购物车中是否有这件商品
            CART cart = null;
            cart = CART_Dao.selectCartByUidAndPid(user.getUSER_ID(),pid);

            if (cart != null){
                //已经有这件商品的购物车
                int srccount = cart.getCART_QUANTITY();
                srccount = srccount+Integer.parseInt(count);
                //限购操作
                if (srccount >= 5){
                    srccount = 5;
                }
                CART_Dao.updateCountById(srccount,cart.getCART_ID());
            }else {
                //如果没有的话就新建一个购物车
                product = PRODUCT_Dao.selectById(pid);
                //创建一个购物车
                cart = new CART(
                        0,
                        product.getPRODUCT_FILENAME(),
                        product.getPRODUCT_NAME(),
                        product.getPRODUCT_PRICE(),
                        Integer.parseInt(count),
                        product.getPRODUCT_STOCE(),
                        product.getPRODUCT_ID(),
                        user.getUSER_ID(),
                        1
                );

                //购物车添加到数据表中
                int insert = CART_Dao.insert(cart);
            }




        }else {
            //用户没有登录，提示用户登录,转跳到登录页面
            PrintWriter out = resp.getWriter();
            out.write("<script>");
            out.write("alert('请先登录之后再进行操作');");
            out.write("location.href='login.jsp';");
            out.write("</script>");
            out.close();

        }

        if (url.equals("z")){
            resp.sendRedirect("showcart");
        }else {
            ArrayList<CART> carts = CART_Dao.selectCartById(user.getUSER_ID());
            req.setAttribute("cartscount",carts.size());
            req.getRequestDispatcher("selectproductview?id="+pid).forward(req,resp);
        }

    }
}
