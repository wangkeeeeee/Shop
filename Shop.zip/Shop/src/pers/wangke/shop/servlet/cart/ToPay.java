package pers.wangke.shop.servlet.cart;

import pers.wangke.shop.dao.CART_Dao;
import pers.wangke.shop.dao.CATE_Dao;
import pers.wangke.shop.dao.PRODUCT_Dao;
import pers.wangke.shop.pojo.CART;
import pers.wangke.shop.pojo.CATEGORY;
import pers.wangke.shop.pojo.USER;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet("/topay")
public class ToPay extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取分类列表
        ArrayList<CATEGORY> flist = CATE_Dao.selectCate("father");
        ArrayList<CATEGORY> clist = CATE_Dao.selectCate("child");

        req.setAttribute("flist",flist);
        req.setAttribute("clist",clist);

        USER user = null;
        HttpSession session = req.getSession();
        String isLogin = String.valueOf(session.getAttribute("isLogin"));
        user = (USER) session.getAttribute("user");

        //判断用户是否登录
        if (user != null && "1".equals(isLogin)){
            //用户已经登录成功
            String order = req.getParameter("order");
            String[] cartids = order.split(",");

            //支付成功删除CART 并且把商品数量库存减去
            for (int i = 0; i < cartids.length;i++){
                CART cart = CART_Dao.selectCartByID(cartids[i]);
                int ncount = cart.getCART_P_STOCK() - cart.getCART_QUANTITY();
                PRODUCT_Dao.updateStock(cart.getCART_P_ID(),ncount);
                CART_Dao.delete(Integer.parseInt(cartids[i]));
            }

            resp.sendRedirect("ok.jsp");
        }else {
            //用户没有登录，提示用户登录,转跳到登录页面
            PrintWriter out = resp.getWriter();
            out.write("<script>");
            out.write("alert('请先登录之后再进行操作');");
            out.write("location.href='login.jsp';");
            out.write("</script>");
            out.close();
        }
    }
}
