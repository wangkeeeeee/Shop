package pers.wangke.shop.servlet.cate;

import pers.wangke.shop.dao.CATE_Dao;
import pers.wangke.shop.pojo.CATEGORY;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/manage/admin_addcate")
public class AddCate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取前端参数
        int parentId =Integer.parseInt(req.getParameter("parentId"));
        String catename = req.getParameter("catename");

        //保存分类
        CATEGORY cate = new CATEGORY(0, catename, parentId);
        int count =  CATE_Dao.insert(cate);

        //判断分类是否保存成功
        if (count > 0){
            //分类保存成功
            req.getRequestDispatcher("admin_cateselect").forward(req,resp);
        }else {
            //分类保存失败
            PrintWriter writer = resp.getWriter();
            writer.write("<script>");
            writer.write("alert('分类添加失败');");
            writer.write("location.href='admin_cateadd.jsp';");
            writer.write("</script>");
            writer.close();
        }
    }
}
