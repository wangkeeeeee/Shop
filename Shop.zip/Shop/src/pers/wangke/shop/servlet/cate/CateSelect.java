package pers.wangke.shop.servlet.cate;

import pers.wangke.shop.dao.CATE_Dao;
import pers.wangke.shop.pojo.CATEGORY;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/manage/admin_cateselect")
public class CateSelect extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ArrayList<CATEGORY> catelist = CATE_Dao.selectAll();

        req.setAttribute("catelist",catelist);

        req.getRequestDispatcher("admin_cate.jsp").forward(req,resp);
    }
}
