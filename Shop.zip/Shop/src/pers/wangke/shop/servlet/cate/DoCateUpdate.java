package pers.wangke.shop.servlet.cate;

import pers.wangke.shop.dao.CATE_Dao;
import pers.wangke.shop.pojo.CATEGORY;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/manage/admin_docateupdate")
public class DoCateUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取前端参数
        int id = Integer.parseInt(req.getParameter("id"));
        int parentId = Integer.parseInt(req.getParameter("parentId"));
        String cateName = req.getParameter("cateName");

        CATEGORY cate = new CATEGORY(id, cateName, parentId);

        //根据修改分类
        CATE_Dao.update(cate);

        req.getRequestDispatcher("admin_cateselect").forward(req,resp);
    }
}
