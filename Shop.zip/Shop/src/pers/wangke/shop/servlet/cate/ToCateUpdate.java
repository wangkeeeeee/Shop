package pers.wangke.shop.servlet.cate;

import pers.wangke.shop.dao.CATE_Dao;
import pers.wangke.shop.pojo.CATEGORY;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/manage/admin_tocateupdate")
public class ToCateUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取前端参数
        int id = Integer.parseInt(req.getParameter("id"));

        //根据id取出cate,并放入req中
        CATEGORY cate = CATE_Dao.selectById(id);
        ArrayList<CATEGORY> catelist = CATE_Dao.selectAll();

        req.setAttribute("cate",cate);
        req.setAttribute("catelist",catelist);

        req.getRequestDispatcher("admin_catemodify.jsp").forward(req,resp);
    }
}
