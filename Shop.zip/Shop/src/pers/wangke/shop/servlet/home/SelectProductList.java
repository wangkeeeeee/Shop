package pers.wangke.shop.servlet.home;

import pers.wangke.shop.dao.CATE_Dao;
import pers.wangke.shop.dao.PRODUCT_Dao;
import pers.wangke.shop.pojo.CATEGORY;
import pers.wangke.shop.pojo.PRODUCT;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/selectproductlist")
public class SelectProductList extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取分类列表
        ArrayList<CATEGORY> flist = CATE_Dao.selectCate("father");
        ArrayList<CATEGORY> clist = CATE_Dao.selectCate("child");

        req.setAttribute("flist",flist);
        req.setAttribute("clist",clist);

        //获取前端页面参数
        String fid = req.getParameter("fid");
        String cid = req.getParameter("cid");



        //进行判断
        int id = 0;
        ArrayList<PRODUCT> prolist = null;
        if (fid != null){
            id = Integer.parseInt(fid);
            prolist = PRODUCT_Dao.selectByfId(id);

            String cateName = CATE_Dao.selectById(id).getCATE_NAME();

            req.setAttribute("fid",id);
            req.setAttribute("cateName",cateName);
            req.setAttribute("prolist",prolist);

            //重定向到产品列表页面
            req.getRequestDispatcher("fproductlist.jsp").forward(req,resp);

        }else if (cid != null){
            id = Integer.parseInt(cid);
            int cate_fid = CATE_Dao.selectById(id).getCATE_PARENT_ID();
            String cate_fName = CATE_Dao.selectById(cate_fid).getCATE_NAME();
            req.setAttribute("cate_fName",cate_fName);
            prolist = PRODUCT_Dao.selectBycId(id);


            String cateName = CATE_Dao.selectById(id).getCATE_NAME();
            req.setAttribute("fid",cate_fid);
            req.setAttribute("cid",id);
            req.setAttribute("cateName",cateName);
            req.setAttribute("prolist",prolist);

            //重定向到产品列表页面
            req.getRequestDispatcher("productlist.jsp").forward(req,resp);
        }


    }

}
