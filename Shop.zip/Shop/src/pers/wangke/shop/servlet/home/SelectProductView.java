package pers.wangke.shop.servlet.home;

import pers.wangke.shop.dao.CART_Dao;
import pers.wangke.shop.dao.CATE_Dao;
import pers.wangke.shop.dao.PRODUCT_Dao;
import pers.wangke.shop.pojo.CART;
import pers.wangke.shop.pojo.CATEGORY;
import pers.wangke.shop.pojo.PRODUCT;
import pers.wangke.shop.pojo.USER;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/selectproductview")
public class SelectProductView extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取分类列表
        ArrayList<CATEGORY> flist = CATE_Dao.selectCate("father");
        ArrayList<CATEGORY> clist = CATE_Dao.selectCate("child");

        req.setAttribute("flist",flist);
        req.setAttribute("clist",clist);

        //获取前端参数
        String pid = req.getParameter("id");

        PRODUCT product = PRODUCT_Dao.selectById(pid);
        req.setAttribute("product",product);
        int fid = product.getPRODUCT_FID();
        req.setAttribute("fid",fid);
        req.setAttribute("cate_fName",CATE_Dao.selectById(fid).getCATE_NAME());
        int cid = product.getPRODUCT_CID();
        req.setAttribute("cid",cid);
        req.setAttribute("cateName",CATE_Dao.selectById(cid).getCATE_NAME());

        ArrayList<PRODUCT> cidProductlist = PRODUCT_Dao.selectBycId(cid);
        req.setAttribute("cidproductlist",cidProductlist);


        //判断用户是否登录，如果登录设置一些参数传过去
        String isLogin = String.valueOf(req.getSession().getAttribute("isLogin"));
        if ("1".equals(isLogin)){
            USER user = (USER) req.getSession().getAttribute("user");
            ArrayList<CART> carts = CART_Dao.selectCartById(user.getUSER_ID());
            req.setAttribute("cartscount",carts.size());
        }

        req.getRequestDispatcher("prodetail.jsp").forward(req,resp);
    }
}
