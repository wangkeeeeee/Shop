package pers.wangke.shop.servlet.user;

import pers.wangke.shop.dao.CART_Dao;
import pers.wangke.shop.dao.CATE_Dao;
import pers.wangke.shop.dao.USER_Dao;
import pers.wangke.shop.pojo.CART;
import pers.wangke.shop.pojo.USER;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet("/login")
public class Login extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取前端参数
        String id = req.getParameter("id");
        String password = req.getParameter("password");


        //判断用户是否为空
        USER user = USER_Dao.selectById(id);
        if (user == null){
            //用户不存在
            PrintWriter out = resp.getWriter();
            out.write("<script>");
            out.write("alert('用户不存在');");
            out.write("location.href='login.jsp';");
            out.write("</script>");
            out.close();
        }

        //判断密码是否正确
        if (password.equals(user.getUSER_PASSWORD())){
            //密码正确
            HttpSession session = req.getSession();
            session.setAttribute("user",user);
            session.setAttribute("isLogin",1);
            resp.sendRedirect("/Shop/indexselect");
        }else {
            //密码错误
            PrintWriter out = resp.getWriter();
            out.write("<script>");
            out.write("alert('用户登陆失败，密码不正确');");
            out.write("location.href='login.jsp';");
            out.write("</script>");
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
