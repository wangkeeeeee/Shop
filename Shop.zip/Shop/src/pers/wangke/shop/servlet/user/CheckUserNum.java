package pers.wangke.shop.servlet.user;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/checkusernum")
public class CheckUserNum extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取前端参数
        String num = req.getParameter("num");
        //获取session
        HttpSession session = req.getSession();
        String code = (String) session.getAttribute("code");


        PrintWriter out = resp.getWriter();
        //与前端返回的验证码进行比对
        if (code.equals(num)){
            //验证码正确
            out.print("true");
        }else {
            //验证码错误
            out.print("false");
        }

        //关闭流
        out.close();
    }
}
