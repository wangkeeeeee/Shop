package pers.wangke.shop.servlet.user;

import pers.wangke.shop.dao.USER_Dao;
import pers.wangke.shop.pojo.USER;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/manage/admin_douserupdate")
public class DoUserUpdate extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取用户参数
        String userName = req.getParameter("userName");
        String name = req.getParameter("name");
        String password = req.getParameter("password");
        String sex = req.getParameter("sex");
        String birthday = req.getParameter("birthday");
        String email = req.getParameter("email");
        String mobile = req.getParameter("mobile");
        String address = req.getParameter("address");
        String cpage = req.getParameter("cpage");

        //创建用户实体
        USER user = new USER(userName, name, password, sex, birthday, null, email, mobile, address, 1);

        //修改数据库中的user
        int count = USER_Dao.updateUser(user);

        //失败或者重定向到哪里
        if (count > 0){
            //修改成功重定向到 之前的用户页面
            resp.sendRedirect("admin_douserselect?cp="+cpage);
        }else{
            //修改失败
            PrintWriter out = resp.getWriter();
            out.write("<script>");
            out.write("alert('用户修改失败')");
            out.write("location.href='manage/admin_touserupdate?id="+userName+"'");
            out.write("</script>");
        }
    }
}
