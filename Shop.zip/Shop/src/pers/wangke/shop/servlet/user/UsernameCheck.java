package pers.wangke.shop.servlet.user;

import pers.wangke.shop.dao.USER_Dao;
import pers.wangke.shop.pojo.USER;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/usernamecheck")
public class UsernameCheck extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取前端参数
        String name = req.getParameter("name");

        //判断数据库中用户名是否存在
        USER user = USER_Dao.selectById(name);

        PrintWriter out = resp.getWriter();
        //进行判断用户是否存在
        if (user != null) {
            //用户存在
            out.print("false");
        }else {
            //用户不存在
            out.print("true");
        }

        out.close();
    }
}
