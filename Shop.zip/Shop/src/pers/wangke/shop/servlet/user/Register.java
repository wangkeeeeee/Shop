package pers.wangke.shop.servlet.user;

import pers.wangke.shop.dao.USER_Dao;
import pers.wangke.shop.pojo.USER;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/register")
public class Register extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取前端参数
        String userName = req.getParameter("id");
        String name = req.getParameter("name");
        String password = req.getParameter("password");
        String sex = req.getParameter("sex");
        String birthday = req.getParameter("birthday");
        String email = req.getParameter("email");
        String mobile = req.getParameter("mobile");
        String address = req.getParameter("address");

        //创建用户实体
        USER user = new USER(userName, name, password, sex, birthday, null, email, mobile, address, 1);

        //加入到数据库的用户表中
        int insert = USER_Dao.insert(user);

        //如果成功或者失败重定向
        if (insert > 0){
            //登录成功，重定向到用户列表页面
            resp.sendRedirect("login.jsp");
        }else {
            //登录失败
            PrintWriter writer = resp.getWriter();
            writer.write("<script>");
            writer.write("alert('用户注册失败');");
            writer.write("location.href='reg.jsp';");
            writer.write("</script>");
        }
    }
}
