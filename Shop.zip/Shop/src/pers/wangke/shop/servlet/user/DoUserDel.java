package pers.wangke.shop.servlet.user;

import pers.wangke.shop.dao.USER_Dao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/manage/admin_douserdel")
public class DoUserDel extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取参数
        String cpage = req.getParameter("cpage");
        String id = req.getParameter("id");

        //根据ID删除用户
        int count = USER_Dao.del(id);

        //进行判断是否删除成功
        if (count > 0){
            //删除成功
            resp.sendRedirect("admin_douserselect?cp="+cpage);
        }else {
            //删除失败
            PrintWriter writer = resp.getWriter();
            writer.write("<script>");
            writer.write("alert('用户删除失败')");
            writer.write("location.href='manage/admin_douserselect?cp="+cpage+"'");
            writer.write("</script>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        //获取要删除的id们
        String[] ids = req.getParameterValues("id[]");

        //遍历要删除的ID
        for (int i = 0; i < ids.length; i++){
            //删除id
            USER_Dao.del(ids[i]);
        }

        //删除完成
        resp.sendRedirect("/Shop/manage/admin_douserselect");
    }
}
