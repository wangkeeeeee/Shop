package pers.wangke.shop.servlet.user;

import pers.wangke.shop.dao.USER_Dao;
import pers.wangke.shop.pojo.USER;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/manage/admin_douserselect")
public class DoUserSelect extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        int cpage = 1;//当前页
        int count = 5;//每页显示条数

        //获取用户指定的页面 cp表示页面参数
        String cp = req.getParameter("cp");
        //接受用户输入的关键词
        String keywords = req.getParameter("keywords");


        //判断
        if (cp != null){
            //把用户指定的页赋值给cpage
            cpage = Integer.parseInt(cp);
        }
        //获取总记录数和页数
        int[] totalPage = USER_Dao.totalPage(count,keywords);

        //获取指定范围页面的用户
        ArrayList<USER> list = USER_Dao.selectAll(cpage,count,keywords);

        //把获取的数据放在请求对象域中
        req.setAttribute("userlist",list);
        req.setAttribute("tsum",totalPage[0]);
        req.setAttribute("tpage",totalPage[1]);
        req.setAttribute("cpage",cpage);

        //判断 如果keywords不为空，则发送数据过去
        if (keywords != null){
            req.setAttribute("searchParams","&keywords="+keywords);
        }
        //转发到前端页面展示
        req.getRequestDispatcher("admin_user.jsp").forward(req,resp);
    }
}
