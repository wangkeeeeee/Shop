package pers.wangke.shop.servlet.user;

import pers.wangke.shop.dao.BaseDao;
import pers.wangke.shop.dao.USER_Dao;
import pers.wangke.shop.pojo.USER;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/manage/admin_touserupdate")
public class ToUserUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置字符集
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=utf-8");

        String id = req.getParameter("id");
        String cpage = req.getParameter("cpage");

        //通过id查找user
        USER user = USER_Dao.selectById(id);

        req.setAttribute("cpage",cpage);
        //把user放进req域中
        req.setAttribute("user",user);

        //转发到修改用户界面
        req.getRequestDispatcher("admin_usermodify.jsp").forward(req,resp);

    }
}
